#!/usr/bin/env python3
"""
Resalta en amarillo SOLO los valores indicados dentro de un document.xml /
header*.xml / footer*.xml ya desempaquetado, dejando intacto el texto que los
rodea (por ejemplo, la etiqueta "Nombre:" no se resalta, solo "Andrea").

Sirve para la revision visual de la Fase A: el cliente ve sobre su propio
documento que se va a convertir en variable y confirma antes de plantillar.

Uso:
    python resaltar.py <ruta/xml> "valor 1" "valor 2" ...

Cada valor debe escribirse EXACTAMENTE como aparece en el documento.
Si un valor esta pegado a su etiqueta en el mismo texto (ej. "Nombre: Andrea"),
pasa solo el valor ("Andrea"): el script parte el texto y resalta unicamente eso.

Imprime cuantas apariciones ha resaltado de cada valor (0 = NO ENCONTRADO:
revisar como esta escrito en el documento, o buscar en header/footer).
"""
import re
import sys

HL = '<w:highlight w:val="yellow"/>'


def _rpr_de(run_open):
    m = re.search(r'<w:rPr>.*?</w:rPr>', run_open, re.S)
    return m.group(0) if m else ''


def resaltar_valor(xml, valor):
    pat = re.compile(
        r'(<w:r\b(?:(?!</w:r>).)*?)(<w:t[^>]*>)((?:(?!</w:t>).)*?'
        + re.escape(valor) +
        r'(?:(?!</w:t>).)*?)(</w:t>)((?:(?!</w:r>).)*?</w:r>)',
        re.S)

    def repl(m):
        run_open, t_open, text, t_close, run_close = m.groups()
        if 'w:highlight' in run_open:
            return m.group(0)
        rpr = _rpr_de(run_open)
        rpr_hl = (rpr.replace('</w:rPr>', HL + '</w:rPr>') if rpr
                  else '<w:rPr>' + HL + '</w:rPr>')
        antes, _, despues = text.partition(valor)
        partes = []
        if antes:
            partes.append('<w:r>' + rpr + '<w:t xml:space="preserve">' + antes + '</w:t></w:r>')
        partes.append('<w:r>' + rpr_hl + '<w:t xml:space="preserve">' + valor + '</w:t></w:r>')
        if despues:
            partes.append('<w:r>' + rpr + '<w:t xml:space="preserve">' + despues + '</w:t></w:r>')
        return ''.join(partes)

    return pat.subn(repl, xml)


def main():
    if len(sys.argv) < 3:
        print('Uso: python resaltar.py <xml> "valor 1" "valor 2" ...')
        sys.exit(1)
    path = sys.argv[1]
    valores = sys.argv[2:]
    xml = open(path, encoding='utf-8').read()
    for valor in valores:
        xml, n = resaltar_valor(xml, valor)
        estado = "OK" if n else "NO ENCONTRADO"
        print('[' + estado + '] ' + valor[:45].ljust(45) + ' -> ' + str(n) + ' aparicion(es)')
    open(path, 'w', encoding='utf-8').write(xml)


if __name__ == '__main__':
    main()
